<?php $__env->startSection('judul'); ?>
    <title>Permintaan Akun MHS</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    Permintaan Akun Mahasiswa
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Data Permintaan Persetujuan Akun</h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Nama Mahasiswa</th>
          <th>Tempat Tanggal Lahir</th>
          <th>Alamat Mahasiswa</th>
          <th>Prodi</th>
          <th>Fakultas</th>
          <th>Angkatan</th>
          <th>Email </th>
          <th>Action </th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($mhs->NIM); ?></td>
                    <td><?php echo e($mhs->NAMA_MHS); ?></td>
                    <td><?php echo e($mhs->TTL); ?></td>
                    <td><?php echo e($mhs->ALAMAT_MHS); ?></td>
                    <td><?php echo e($mhs->PRODI); ?></td>
                    <td><?php echo e($mhs->FAKULTAS); ?></td>
                    <td><?php echo e($mhs->ANGKATAN); ?></td>
                    <td><?php echo e($mhs->EMAIL_MHS); ?></td>
                    <td><form class="" action="<?php echo e(route('mahasiswa.action',$mhs->EMAIL_MHS)); ?>" method="post" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>

                        <button class="btn btn-success">Terima</button>
                    </form>
                    <form class="" action="<?php echo e(route('mahasiswa.action2',$mhs->EMAIL_MHS)); ?>" method="post" enctype="multipart/form-data"  >
                        <?php echo csrf_field(); ?>

                        <button class="btn btn-danger" style="margin-top: 15px">Tolak </button>
                    </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.kampus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/kampus/mahasiswa_acc.blade.php ENDPATH**/ ?>