<?php $__env->startSection('judul'); ?>
<title>List UKM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
List UKM
<hr>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Data Unit Kegiatan Mahasiswa</h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>Nama UKM </th>
          <th>Nama Ketua UKM</th>
          <th>Tahun Berdiri</th>
          <th>Deskripsi UKM</th>
          <th>Logo </th>
          <th>Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($uk->NAMA_UKM); ?></td>
                    <td><?php echo e($uk->NAMA_KETUA); ?></td>
                    <td><?php echo e($uk->TAHUN_BERDIRI); ?></td>
                    <td><textarea readonly rows="16" cols="28" style="border: none" ><?php echo e($uk->DESKRIPSI_UKM); ?> </textarea></td>
                    <td><img src="<?php echo e(asset('images/'.$uk->LOGO)); ?>" style="width: 200px"></td>
                    <td>
                        <a href="<?php echo e(route('detail.anggota', $uk->ID_UKM)); ?>" class="btn btn-info">List Anggota</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.kampus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/kampus/ListUKM.blade.php ENDPATH**/ ?>