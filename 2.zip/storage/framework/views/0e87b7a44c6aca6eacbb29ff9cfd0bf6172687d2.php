<?php $__env->startSection('judul'); ?>
    <title>Join UKM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    Join UKM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">List UKM</h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>Logo</th>
          <th>Nama UKM</th>
          <th>Action </th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <input type="hidden" value="<?php echo e($uk->ID_UKM); ?>">
                    <td><img src="<?php echo e(asset('images/'.$uk->LOGO)); ?>" style="width: 200px"></td>
                    <td><?php echo e($uk->NAMA_UKM); ?></td>
                    <td style="width: 100px">
                        <form class="" action="<?php echo e(route('mhs.ukm',$uk->ID_UKM)); ?>" id="form" method="post" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="NIM" value="<?php echo e(Session::get('NIM')); ?>">
                            <input type="hidden" name="id_ukm" value="<?php echo e($uk->ID_UKM); ?>">
                            <input type="hidden" name="status_anggota" value="Tidak Aktif">
                            <button class="btn btn-success" id="join" >Join </button>
                            <a href=" <?php echo e(route('detail.ukm', $uk->ID_UKM)); ?>" class="btn btn-info" style="margin-top:20px ">Detail</a>
                        </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>


  <script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>
  <script>
      $(document).on('submit','#form',function(e){
        e.preventDefault();
        let url =$(this).attr('action')
        let form = new FormData(this)

        $.ajaxSetup({

        headers: {
            'X-CRSF-TOKEN' : $('meta[name="crsf-token"]').attr('content')
        }

    })

    $.ajax({
        type:"POST",
        url: url,
        data:form,
        dataType: "JSON",
        processData:false,
        contentType:false,
        success: function(response){
            //console.log(response)
            if(response.bergabung){
                swal("Gagal",response.bergabung,"error");
            }else if(response.terdaftar){
                swal("Info",response.terdaftar,"info");
            }else if(response.sukses){
                swal("Berhasil",response.sukses,"success");
            }
        }

    });

    })
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.mhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/mahasiswa/joinUKM.blade.php ENDPATH**/ ?>