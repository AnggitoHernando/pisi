<?php $__env->startSection('judul'); ?>
    <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <title> Detail UKM <?php echo e($uk->NAMA_UKM); ?></title>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        Detail UKM <?php echo e($uk->NAMA_UKM); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

    <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                <h3 class="card-title">Detail UKM <?php echo e($uk->NAMA_UKM); ?> </h3>
            </div>

        <div class="card-body">
            <img src="<?php echo e(asset('images/'.$uk->LOGO)); ?>" alt="Logo UKM" style="width: 300px; margin-left: auto; margin-right: auto; display: block;">
            <h4 style="margin-top: 20px">Nama UKM         :<?php echo e($uk->NAMA_UKM); ?></h4>
            <h4>Ketua            :<?php echo e($uk->NAMA_KETUA); ?></h4>
            <h4>Tahun Berdiri    :<?php echo e($uk->TAHUN_BERDIRI); ?></h4>
            <h4>Deskripsi dan Syarat Gabung:</h4>
            <textarea readonly rows="20" cols="100" class="detail" style="border: none; font-size: 1.5rem"><?php echo e($uk->DESKRIPSI_UKM); ?></textarea>
            <a class="btn btn-success" style="float: right;" href="<?php echo e(route('list.ukm',$NIM=Session::get('NIM'))); ?>">Kembali </a>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/mahasiswa/detailukm2.blade.php ENDPATH**/ ?>