<?php $__env->startSection('judul'); ?>
<?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title>Pengaturan Akun <?php echo e($uk->NAMA_UKM); ?></title>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
<?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    Pengaturan Akun <?php echo e($uk->NAMA_UKM); ?>

<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
    <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Pengaturan Akun </h3>
        </div>

    <div class="card-body">
        <form id="form" action="<?php echo e(route('Edit.UKM')); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
            <input type="hidden" id="id_kam" value="<?php echo e($uk->ID_UKM); ?>">
            <label for="basic-url" class="form-label">Nama UKM</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="nama_ukm" aria-describedby="basic-addon3" value="<?php echo e($uk->NAMA_UKM); ?>" name="nama_UKM" readonly>
            </div>
            <label for="basic-url" class="form-label">Nama Ketua</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="nama_ketua" aria-describedby="basic-addon3" value="<?php echo e($uk->NAMA_KETUA); ?>" name="nama_ketua" readonly>
            </div>
            <label for="basic-url" class="form-label">Tahun Berdiri</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="tahun_berdiri" aria-describedby="basic-addon3" value="<?php echo e($uk->TAHUN_BERDIRI); ?>" name="tahun_berdiri" readonly>
            </div>
            <label for="basic-url" class="form-label">Deskripsi UKM dan Syarat Gabung</label>
            <div class="input-group mb-3">
                <textarea class="form-control" rows="20" cols="100" id="deskripsi" aria-describedby="basic-addon3"  name="deskripsi_ukm" readonly><?php echo e($uk->DESKRIPSI_UKM); ?></textarea>
            </div>
            <label for="basic-url" class="form-label">Logo</label>
            <div class="input-group mb-3">
                <img src="<?php echo e(asset('images/'.$uk->LOGO)); ?>" alt="Logo UKM" style="width: 300px; margin-right:15px; display: block;" class="img-thumbnail">
            </div>
            <div class="input-group mb-3">
                <input type="file" class="form-control" id="logo" aria-describedby="basic-addon3" name="logo" disabled>
            </div>
            <label for="basic-url" class="form-label">Email UKM</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="email" aria-describedby="basic-addon3" value="<?php echo e($uk->EMAIL_UKM); ?>" name="email_ukm" readonly>
            </div>
            <label for="basic-url" class="form-label">Username</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="username" aria-describedby="basic-addon3" value="<?php echo e($uk->USERNAME_UKM); ?>" name="username_UKM" readonly>
            </div>
            <label for="basic-url" class="form-label">Pendaftaran</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="pendaftaran" aria-describedby="basic-addon3" value="<?php echo e($uk->PENDAFTARAN); ?>" name="pendaftaran" readonly>
            </div>
            <a class="btn btn-secondary" id="edit" style="color: white"> Edit</a>
            <button style="float: right ;color: white" id="simpan" class="btn btn-success">Simpan</button>
            <a style="float: right; color: white; margin-right: 15px" id="batal" class="btn btn-danger">Batal</a>
            <?php echo e(csrf_field()); ?>

        </form>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>
    <script>
    var pass1 =document.getElementById("nama_ukm").value;

    $("#batal").hide();
    $("#simpan").hide();
    $(function(){
      $('#edit').click(function(){
        $('input').removeAttr('readonly','readonly');
        $('#deskripsi').removeAttr('readonly','readonly');
        $('#logo').removeAttr('disabled','disabled');
        $('#batal').show();
        $('#simpan').show();
      });
    });

    $(function(){
      $('#batal').click(function(){
        $('input').attr('readonly',true);
        $('#deskripsi').attr('readonly',true);
        $('#logo').trigger('cancel');
        $('#logo').attr('disabled',true);
        $('#batal').hide();
        $('#simpan').hide();
      });
    });

    $(document).on('submit','#form',function(e){
        e.preventDefault();
        let url =$(this).attr('action')
        let form = new FormData(this)

        $.ajaxSetup({

        headers: {
            'X-CRSF-TOKEN' : $('meta[name="crsf-token"]').attr('content')
        }

    })

    $.ajax({
        type:"POST",
        url: url,
        data:form,
        dataType: "JSON",
        processData:false,
        contentType:false,
        success: function(response){
            //console.log(response)
            if(response.gambar){
                $('.img-thumbnail').attr('src', response.gambar).change
            }else if(response.sukses){
                $('#simpan').html('Simpan');
                $('input').attr('readonly',true);
                $('#deskripsi').attr('readonly',true);
                $('#batal').hide();
                $('#simpan').hide();
                swal("Berhasil!",response.sukses,"success");
            }
        }

    });

    })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.ukm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/ukm/EditAkunUKM.blade.php ENDPATH**/ ?>