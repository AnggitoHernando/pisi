<?php $__env->startSection('judul'); ?>
    <title>List Anggota UKM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    List Anggota UKM
    <hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Data Anggota UKM</h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Nama Mahasiswa</th>
          <th>Tempat Tanggal Lahir</th>
          <th>Alamat Mahasiswa</th>
          <th>Prodi</th>
          <th>Fakultas</th>
          <th>Angkatan</th>
          <th>Status</th>
          <th>Action </th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <input type="hidden" value="<?php echo e($ang->ID_ANGGOTA); ?>">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($ang->NIM); ?></td>
                    <td><?php echo e($ang->NAMA_MHS); ?></td>
                    <td><?php echo e($ang->TTL); ?></td>
                    <td><?php echo e($ang->ALAMAT_MHS); ?></td>
                    <td><?php echo e($ang->PRODI); ?></td>
                    <td><?php echo e($ang->FAKULTAS); ?></td>
                    <td><?php echo e($ang->ANGKATAN); ?></td>
                    <td><?php echo e($ang->STATUS_ANGGOTA); ?></td>
                    <td>

                        <a class="btn btn-info" href="<?php echo e(route('list.action',$ang->ID_ANGGOTA)); ?>">Detail Anggota</a>

                         <form class="" action="<?php echo e(route('list.action2',$ang->ID_ANGGOTA)); ?>" method="post" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>

                            <button class="btn btn-danger" style="margin-top: 15px" onclick="return confirm('Yakin Anggota Akan Dihapus??')">Hapus Anggota </button>
                         </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.ukm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/ukm/ListAnggota.blade.php ENDPATH**/ ?>