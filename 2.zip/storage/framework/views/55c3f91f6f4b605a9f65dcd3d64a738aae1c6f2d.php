<?php $__env->startSection('judul'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="col-12">
<div class="card">
    <div class="card-header">
    <h3 class="card-title">List UKM</h3>
</div>

<div class="card-body">
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/mahasiswa/dashboard.blade.php ENDPATH**/ ?>