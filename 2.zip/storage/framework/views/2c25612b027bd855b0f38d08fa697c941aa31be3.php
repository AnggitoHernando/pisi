<div class="col-12">
    <div class="card">
        <div class="card-header">
        <h3 class="card-title"><?php echo $__env->yieldContent('judul_tabel'); ?></h3>
    </div>

<div class="card-body">
  <table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <?php echo $__env->yieldContent('tableheader'); ?>

    </tr>
    </thead>
    <tbody>
       <?php echo $__env->yieldContent('isitabel'); ?>
    </tbody>
  </table>
</div>
<!-- /.card-body -->
</div>
<?php /**PATH C:\xampp\htdocs\pisi\resources\views/layout/tabel.blade.php ENDPATH**/ ?>