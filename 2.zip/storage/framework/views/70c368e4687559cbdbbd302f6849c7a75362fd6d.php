<?php $__env->startSection('judul'); ?>
<title>Pengaturan Akun</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
Pengaturan Akun
<hr>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
    <?php $__currentLoopData = $kampus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Pengaturan Akun</h3>
        </div>

    <div class="card-body">
        <form class="registrasi-form" enctype="multipart/form-data" id="frm_edit" >
        <?php echo csrf_field(); ?>
            <input type="hidden" id="id_kam" value="<?php echo e($kam->ID_KAMPUS); ?>">
            <label for="basic-url" class="form-label">Nama Kampus</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url kampus" aria-describedby="basic-addon3" value="<?php echo e($kam->NAMA_KAMPUS); ?>" name="nama_kampus" readonly>
            </div>
            <label for="basic-url" class="form-label">Alamat</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url kampus" aria-describedby="basic-addon3" value="<?php echo e($kam->ALAMAT_KAMPUS); ?>" name="alamat_kampus" readonly>
            </div>
            <label for="basic-url" class="form-label">Username</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url kampus" aria-describedby="basic-addon3" value="<?php echo e($kam->USERNAME_KAMPUS); ?>" name="username_kampus" readonly>
            </div>
            <a class="btn btn-secondary" id="edit" style="color: white"> Edit</a>
            <a style="float: right ;color: white" id="simpan" class="btn btn-success">Simpan</a>
            <a style="float: right; color: white; margin-right: 15px" id="batal" class="btn btn-danger">Batal</a>
            <?php echo e(csrf_field()); ?>

        </form>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>
    <script>
    $("#batal").hide();
    $("#simpan").hide();
    $(function(){
      $('#edit').click(function(){
        $('input').removeAttr('readonly','readonly');
        $('#batal').show();
        $('#simpan').show();
      });
    });
    $(function(){
      $('#batal').click(function(){
        $('input').attr('readonly',true);
        $('#batal').hide();
        $('#simpan').hide();
      });
    });

    $('#simpan').click(function (e) {
        var cek =document.getElementById("id_kam").value;;
        e.preventDefault();
        $(this).html('Menyimpan..');
        $.ajax({
        data: $('#frm_edit').serialize(),
        url: "<?php echo e(route('Edit.Kampus')); ?>",
        type: "POST",
        success: function (data) {
        console.log(data);
        $('#simpan').html('Simpan');
        $('input').attr('readonly',true);
        $('#batal').hide();
        $('#simpan').hide();
        swal("Berhasil!","Data Berhasil Disimpan","success");
        },
        error: function (data) {
        console.log('Error:', data);
        $('#simpan').html('Gagal simpan data');
        }

        });


    });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.kampus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/kampus/EditAkunKampus.blade.php ENDPATH**/ ?>