<?php $__env->startSection('judul'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.ukm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/ukm/dashboard.blade.php ENDPATH**/ ?>