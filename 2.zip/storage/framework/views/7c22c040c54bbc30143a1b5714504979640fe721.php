<?php $__env->startSection('namauser'); ?>
    <?php $__currentLoopData = $kampus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span style="color:lightgray"> Hai. <?php echo e($ka->NAMA_KAMPUS); ?></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pengaturan'); ?>
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fas fa-cog"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <span class="dropdown-item dropdown-header">Pengaturan</span>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('ganti.password_kampus')); ?>" class="dropdown-item">
                <i class="fas fa-key mr-3"></i> Ganti Password
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('Pengaturan.Kampus')); ?>" class="dropdown-item">
                <i class="fas fa-users mr-3"></i>Pengaturan Akun
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-item">
                <i class="fas fa-sign-out-alt mr-3 "></i> Keluar
            </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item dropdown-footer">Sistem Informasi UKM</a>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('menu'); ?>
    
    <li class="nav-item has-treeview">
        <a href="" class="nav-link ">
            <i class="nav-icon fas fa-user-plus"></i>
            <p>
            Permintaan Akun
            <i class="fas fa-angle-left right"></i>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item">
            <a href="<?php echo e(route('permintaan_akun')); ?>" class="nav-link <?php echo e(set_active('permintaan_akun')); ?>">
                <i class="far fas fa-user nav-icon"></i>
                <p>Mahasiswa</p>
            </a>
            </li>
            <li class="nav-item">
            <a href="<?php echo e(route('permintaan_akun.UKM')); ?>" class="nav-link <?php echo e(set_active('permintaan_akun.UKM')); ?>">
                <i class="far fas fa-users nav-icon"></i>
                <p>Unit Kegiatan Mahasiswa</p>
            </a>
        </ul>
        </li>
        <li class="nav-item ">
            <a href="<?php echo e(route('list.ukm')); ?>" class="nav-link <?php echo e(set_active('list.ukm')); ?>">
            <i class="far fas fa-users nav-icon"></i>
            <p>
                List Nama UKM
            </p>
            </a>
        </li>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/layout/kampus.blade.php ENDPATH**/ ?>