<?php $__env->startSection('namauser'); ?>
    <span style="color:lightgray"> Hai, Admin UKM <?php echo e(Session::get('NAMA_UKM')); ?></span>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pengaturan'); ?>
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fas fa-cog"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <span class="dropdown-item dropdown-header">Pengaturan</span>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('ganti.password_ukm')); ?>" class="dropdown-item">
                <i class="fas fa-key mr-3"></i> Ganti Password
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('Pengaturan.UKM')); ?>" class="dropdown-item">
                <i class="fas fa-users mr-3"></i>Pengaturan Akun
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-item">
                <i class="fas fa-sign-out-alt mr-3 "></i> Keluar
            </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item dropdown-footer">Sistem Informasi UKM</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    
    <li class="nav-item">
        <a href="<?php echo e(route('permintaan.masuk',$NAMA_UKM=Session::get('NAMA_UKM'))); ?>" class="nav-link <?php echo e(set_active('permintaan.masuk')); ?>">
            <i class="nav-icon fas fa-user-plus"></i>
            <p>
            Permintaan Masuk UKM
            </p>
        </a>
        <li class="nav-item ">
            <a href="<?php echo e(route('list.anggota',$NAMA_UKM=Session::get('NAMA_UKM'))); ?>" class="nav-link <?php echo e(set_active('list.anggota')); ?>">
            <i class="far fas fa-users nav-icon"></i>
            <p>
                List Anggota UKM
            </p>
            </a>
        </li>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/layout/ukm.blade.php ENDPATH**/ ?>