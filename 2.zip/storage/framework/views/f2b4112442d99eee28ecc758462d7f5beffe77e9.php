<?php $__env->startSection('judul'); ?>
<title>List Anggota UKM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
List Anggota UKM
<hr>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title"></h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>NIM</th>
          <th>Nama Mahasiswa</th>
          <th>Tempat Tanggal Lahir</th>
          <th>Alamat</th>
          <th>Prodi</th>
          <th>Fakultas</th>
          <th>Angkatan/Tahun Masuk</th>
          <th>No. Telepon</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($ang->NIM); ?></td>
                    <td><?php echo e($ang->NAMA_MHS); ?></td>
                    <td><?php echo e($ang->TTL); ?></td>
                    <td><?php echo e($ang->ALAMAT_MHS); ?></td>
                    <td><?php echo e($ang->PRODI); ?></td>
                    <td><?php echo e($ang->FAKULTAS); ?></td>
                    <td><?php echo e($ang->ANGKATAN); ?></td>
                    <td><?php echo e($ang->NO_TELFON); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.kampus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/kampus/DetailAnggota.blade.php ENDPATH**/ ?>