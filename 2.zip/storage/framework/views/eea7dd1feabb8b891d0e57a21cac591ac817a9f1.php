<?php $__env->startSection('judul'); ?>
<?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title>Pengaturan Akun <?php echo e($m->NAMA_MHS); ?></title>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
<?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    Pengaturan Akun <?php echo e($m->NAMA_MHS); ?>

<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
    <?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Pengaturan Akun</h3>
        </div>

    <div class="card-body">
        <form id="frm_edit" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
            <input type="hidden" id="NIM" value="<?php echo e($m->NIM); ?>">
            <label for="basic-url" class="form-label">NIM</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="nama_mhs" aria-describedby="basic-addon3" value="<?php echo e($m->NIM); ?>" name="NIM" readonly>
            </div>
            <label for="basic-url" class="form-label">Nama Mahasiswa</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->NAMA_MHS); ?>" name="NAMA_MHS" readonly>
            </div>
            <label for="basic-url" class="form-label">Alamat</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->ALAMAT_MHS); ?>" name="alamat_mhs" readonly>
            </div>
            <label for="basic-url" class="form-label">Tempat, Tanggal Lahir</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->TTL); ?>" name="ttl" readonly>
            </div>
            <label for="basic-url" class="form-label">Fakultas</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->FAKULTAS); ?>" name="fakultas" readonly>
            </div>
            <label for="basic-url" class="form-label">Program Studi</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->PRODI); ?>" name="prodi" readonly>
            </div>
            <label for="basic-url" class="form-label">Angkatan/Tahun Masuk</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->ANGKATAN); ?>" name="angkatan" readonly>
            </div>
            <label for="basic-url" class="form-label">No. Telepon</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->NO_TELFON); ?>" name="no_telepon" readonly>
            </div>
            <label for="basic-url" class="form-label">Email</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->EMAIL_MHS); ?>" name="email" readonly>
            </div>
            <label for="basic-url" class="form-label">Username</label>
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="basic-url mhs" aria-describedby="basic-addon3" value="<?php echo e($m->USERNAME_MHS); ?>" name="username" readonly>
            </div>
            <a class="btn btn-secondary" id="edit" style="color: white"> Edit</a>
            <a style="float: right ;color: white" id="simpan" class="btn btn-success">Simpan</a>
            <a style="float: right; color: white; margin-right: 15px" id="batal" class="btn btn-danger">Batal</a>
            <?php echo e(csrf_field()); ?>

        </form>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e(asset('backend/plugins/jquery/jquery.min.js')); ?>"></script>
    <script>

    $("#batal").hide();
    $("#simpan").hide();
    $(function(){
      $('#edit').click(function(){
        $('input').removeAttr('readonly','readonly');
        $('#batal').show();
        $('#simpan').show();
      });
    });
    $(function(){
      $('#batal').click(function(){
        $('input').attr('readonly',true);
        $('#deskripsi').attr('readonly',true);
        $('#logo').trigger('cancel');
        $('#logo').attr('disabled',true);
        $('#batal').hide();
        $('#simpan').hide();
      });
    });

    $('#simpan').click(function (e) {
        e.preventDefault();
        $(this).html('Menyimpan..');
        $.ajax({
        data: $('#frm_edit').serialize(),
        url: "<?php echo e(route('Edit.Mhs')); ?>",
        type: "POST",
        success: function (data) {
        console.log(data);
        $('#simpan').html('Simpan');
        $('input').attr('readonly',true);
        $('#batal').hide();
        $('#simpan').hide();
        swal("Berhasil!","Data Berhasil Disimpan","success");
        },
        error: function (data) {
        console.log('Error:', data);
        $('#simpan').html('Gagal simpan data');
        swal("Gagal","Data Gagal Disimpan","error");
        }

        });


    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/mahasiswa/EditAkunMhs.blade.php ENDPATH**/ ?>