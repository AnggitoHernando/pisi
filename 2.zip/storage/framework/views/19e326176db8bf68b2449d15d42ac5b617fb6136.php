<nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3" id="mainNav">
    <a class="navbar-brand js-scroll-trigger" href="#page-top"> <img class="logo" src="<?php echo e(asset('frontend/halamandepan/img/logo.png')); ?>" alt="logo UINSA" style="width:100px; height:auto;"></img></a>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="/login" >Login</a></li>
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#about" >Halaman Depan</a></li>
        </ul>
    </div>
    </nav><?php /**PATH C:\xampp\htdocs\pisi\resources\views/layout/layoutdepan.blade.php ENDPATH**/ ?>