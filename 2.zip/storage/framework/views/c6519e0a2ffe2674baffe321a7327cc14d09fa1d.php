<?php $__env->startSection('judul'); ?>
<title>Permintaan Akun UKM</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
Permintaan Akun UKM
<hr>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('konten'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h3 class="card-title">Data Permintaan Persetujuan Akun</h3>
        </div>

    <div class="card-body">
      <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>No.</th>
          <th>Nama UKM </th>
          <th>Nama Ketua UKM</th>
          <th>Tahun Berdiri</th>
          <th>Deskripsi UKM</th>
          <th>Logo </th>
          <th>Email </th>
          <th>Action </th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <input type="hidden" value="<?php echo e($uk->ID_UKM); ?>">
                    <td><?php echo e($uk->NAMA_UKM); ?></td>
                    <td><?php echo e($uk->NAMA_KETUA); ?></td>
                    <td><?php echo e($uk->TAHUN_BERDIRI); ?></td>
                    <td><textarea readonly rows="16" cols="28" style="border: none" ><?php echo e($uk->DESKRIPSI_UKM); ?> </textarea></td>
                    <td><img src="<?php echo e(asset('images/'.$uk->LOGO)); ?>" style="width: 200px"></td>
                    <td><?php echo e($uk->EMAIL_UKM); ?></td>
                    <td>
                        <form class="" action="<?php echo e(route('ukm.action',$uk->EMAIL_UKM)); ?>" method="post" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>
                            <button class="btn btn-success">Terima</button>
                        </form>
                        <form class="" action="<?php echo e(route('ukm.action2',$uk->EMAIL_UKM)); ?>" method="post" enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>

                            <button class="btn btn-danger" style="margin-top: 15px">Tolak </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.kampus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/kampus/ukm_acc.blade.php ENDPATH**/ ?>