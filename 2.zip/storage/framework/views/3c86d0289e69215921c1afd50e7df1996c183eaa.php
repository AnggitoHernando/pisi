<?php $__env->startSection('namauser'); ?>

    <span style="color:lightgray"> Hai, <?php echo e(Session::get('NAMA_MHS')); ?></span>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pengaturan'); ?>
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fas fa-cog"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <span class="dropdown-item dropdown-header">Pengaturan</span>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('ganti.password_mhs')); ?>" class="dropdown-item">
                <i class="fas fa-key mr-3"></i> Ganti Password
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('Pengaturan.Mhs')); ?>" class="dropdown-item">
                <i class="fas fa-users mr-3"></i>Pengaturan Akun
            </a>
        <div class="dropdown-divider"></div>
            <a href="<?php echo e(route('user.logout')); ?>" class="dropdown-item">
                <i class="fas fa-sign-out-alt mr-3 "></i> Keluar
            </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item dropdown-footer">Sistem Informasi UKM</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
         
        <li class="nav-item">
            <a href="<?php echo e(route('mhs.join')); ?>" class="nav-link <?php echo e(set_active('mhs.join')); ?> <?php echo e(set_active('detail.ukm')); ?>">
            <i class="nav-icon fas fa-user-plus"></i>
             <p>
            Join UKM
            </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('status.pendaftaran')); ?>" class="nav-link <?php echo e(set_active('status.pendaftaran')); ?> ">
            <i class="nav-icon fas fa-clock"></i>
             <p>
            Status Pendaftaran UKM
            </p>
            </a>
        </li>
        <li class="nav-item ">
            <a href="<?php echo e(route('list.diikuti',$NIM=Session::get('NIM'))); ?>" class="nav-link <?php echo e(set_active('list.diikuti')); ?> <?php echo e(set_active('detail.ukm2')); ?>">
            <i class="far fas fa-users nav-icon"></i>
            <p>
                List UKM Yang Diikuti
            </p>
            </a>
        </li>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/layout/mhs.blade.php ENDPATH**/ ?>