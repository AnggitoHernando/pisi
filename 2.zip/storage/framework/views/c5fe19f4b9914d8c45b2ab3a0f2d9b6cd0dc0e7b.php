<?php $__env->startSection('judul'); ?>
    <title>Pendaftaran UKM</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <form class="registrasi-form" action="<?php echo e(route('ukm.tambah')); ?>" method="post" enctype="multipart/form-data" >
    <?php echo csrf_field(); ?>
        <span class="title">
            Registrasi UKM
        </span>
        <div class="form-grup">
            <span class="label-input">Nama UKM</span>
            <input class="reg-input" type="text" name="nama_ukm" placeholder="Masukkan Nama UKM" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" value="<?php echo e(old('nama_ukm')); ?>">
            <span class="focus-input100"></span>
        </div>
        <div class="form-grup">
            <span class="label-input">Nama Ketua</span>
            <input class="reg-input" type="text" name="nama_ketua" placeholder="Masukkan Nama Ketua UKM" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" value="<?php echo e(old('nama_ketua')); ?>">
            <span class="focus-input100"></span>
        </div>
        <div class="form-grup <?php if($errors->has('tahun')): ?> has-error <?php endif; ?>" >
            <span class="label-input">Tahun Berdiri</span>
            <input class="reg-input" type="text" name="tahun" placeholder="Tahun Berdiri UKM" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" value="<?php echo e(old('tahun')); ?>">
            <span class="focus-input100"></span>
            <?php if($errors->has('tahun')): ?> <span class="help-block"><?php echo e($errors->first('tahun')); ?> <?php endif; ?></span>
        </div>
        <div class="form-grup">
            <span class="label-input">Deskripsi UKM</span>
            <textarea class="reg-input" type="text" name="deskripsi" placeholder="Masukkan Deskripsi UKM" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" ><?php echo e(old('deskripsi')); ?></textarea>
            <span class="focus-input100"></span>
        </div>
        <div class="form-grup ">
            <span class="label-input">Logo</span>
            <input class="reg-input" type="file" name="logo">
            <span class="focus-input100"></span>
        </div>
        <div class="form-grup <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
            <span class="label-input">Email</span>
            <input class="reg-input" type="text" name="email" placeholder="Masukkan Email" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" value="<?php echo e(old('email')); ?>">
            <span class="focus-input100"></span>
            <?php if($errors->has('email')): ?> <span class="help-block"><?php echo e($errors->first('email')); ?> <?php endif; ?></span>
        </div>
        <div class="form-grup">
            <span class="label-input">Username</span>
            <input class="reg-input" type="text" name="username" placeholder="Masukkan Username" required  oninvalid="this.setCustomValidity('Data Tidak Boleh Kosong')" oninput="setCustomValidity('')" value="<?php echo e(old('username')); ?>">
            <span class="focus-input100"></span>
        </div>
        <div class="form-grup">
            <span class="label-input">Password</span>
            <input class="reg-input" type="password" id="password" name="password" placeholder="Masukkan Password" required >
            <span class="focus-input100"></span>
            <input type="checkbox" class="show-hide" name="show-hide" value="" />
            <label for="show-hide">Tampilkan Password</label>
        </div>

        <div class="register-btn-submit">
            <button class="btn-submit" type="submit">Daftar </button>
            <a class="back" href="<?php echo e(route('hal.depan')); ?>">Back</a> <a class="akun" href="">Sudah Punya Akun?</a>
        </div>

        <script src="<?php echo e(asset('frontend/halamandepan/vendor/jquery/jquery.min.js')); ?>"></script>
        <script>
            $(document).ready(function(){
		$('.show-hide').click(function(){
			if($(this).is(':checked')){
				$('#password').attr('type','text');
			}else{
				$('#password').attr('type','password');
			}
		});
	    });
    </script>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/halamandepan/registerukm.blade.php ENDPATH**/ ?>