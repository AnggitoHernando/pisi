<?php $__env->startSection('judul'); ?>
    <?php $__currentLoopData = $tes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <title> Detail <?php echo e($uk->NAMA_MHS); ?></title>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nama_fitur'); ?>
    <?php $__currentLoopData = $tes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        Detail <?php echo e($uk->NAMA_MHS); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

    <?php $__currentLoopData = $tes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                <h3 class="card-title">Detail <?php echo e($uk->NAMA_MHS); ?> </h3>
            </div>

        <div class="card-body">
            <h4>NIM Mahasiswa           :<?php echo e($uk->NIM); ?></h4>
            <h4>Nama Mahasiswa          :<?php echo e($uk->NAMA_MHS); ?></h4>
            <h4>Tempat Tanggal Lahir    :<?php echo e($uk->TTL); ?></h4>
            <h4>Alamat                  :<?php echo e($uk->ALAMAT_MHS); ?></h4>
            <h4>Fakultas                :<?php echo e($uk->FAKULTAS); ?></h4>
            <h4>Prodi                   :<?php echo e($uk->PRODI); ?></h4>
            <h4>Tahun Masuk/Angkatan    :<?php echo e($uk->ANGKATAN); ?></h4>
            <a class="btn btn-success" style="float: right;" href="<?php echo e(route('list.anggota',$NAMA_UKM=Session::get('NAMA_UKM'))); ?>">Kembali </a>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.ukm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pisi\resources\views/backend/ukm/detail_anggota.blade.php ENDPATH**/ ?>